#define SPH_SVN_TAG "rel20"
#define SPH_SVN_REV 3043
#define SPH_SVN_REVSTR "3043"
#define SPH_SVN_TAGREV "r3043"
#define SPHINX_TAG "-release"
